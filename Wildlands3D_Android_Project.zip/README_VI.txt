WILDLANDS 3D — ANDROID PROJECT

Đây là mã nguồn dự án Android bọc game web bằng WebView, chưa phải file APK đã biên dịch.

Cách tạo APK:
1. Cài Android Studio trên máy tính.
2. Giải nén Wildlands3D_Android_Project.zip.
3. Mở thư mục Wildlands3D_Android_Project bằng Android Studio.
4. Chờ Gradle Sync và cài Android SDK Platform 35 nếu được yêu cầu.
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio sẽ hiển thị đường dẫn APK sau khi build thành công.

Lưu ý:
- Game dùng Three.js từ CDN https://cdn.jsdelivr.net, vì vậy cần Internet để tải thư viện 3D.
- Đây là bản đóng gói sơ bộ; cần chạy thử trên thiết bị thật và sửa lỗi nếu có.
- Không đổi tên file ZIP thành .apk; phải biên dịch dự án Android.
